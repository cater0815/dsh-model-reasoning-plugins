/** Replacement model picker is implemented in the Client half. */
export function apply() {}
