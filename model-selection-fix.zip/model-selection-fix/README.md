# 模型与推理等级同步修复

本 bundle 替代 DSH `0.2.0-rc.2` 的内置模型选择客户端；安装时禁用内置选择器、启用此修复版，不修改 Host 模型适配器或用户凭据。`client.js` 从该版本内置客户端复制，保留原有模型菜单与 `/model`，并修复共享 `ModelDirectory`：

- 切换模型时提交完整的 provider/model/effort；按 Host `selectModel` 返回的规范化结果更新显示（而非只信提交前的值）。
- 在持久投影尚未送达期间保留已确认的选择；较新的投影取代旧选择，不让迟到的 RPC 响应重新覆盖它。
- Remote 拒绝或连接异常清除 pending，过期结果不覆盖后续选择；重新连接时清空上一代临时状态。

两侧本机滑动条现在调用 `modelDirectories.directoryFor(sessionId).select()`，与菜单共用该状态流；已停用绕过目录的直接 `ctx.remote.session.selectModel()` 调用。模型不可用时，右侧滑动条显示会话保存的 provider/model ID，而不是误指向可用目录第一项。

## 应用与验证

- 已用 `plugin_manager.install_bundle` 将本包安装到 web profile，安装结果 `application: applied`。配置中内置模型选择器 inactive，替代包 active。工作区的这个目录是 profile 安装链接的源目录，**不要删除或改名**。
- 在工作目录执行 `node dsh-fix/model-selection-regression.mjs` 和 `node dsh-fix/model-selection-agent-regression.mjs`，验证目录竞态、两个滑动条共用状态与 Agent 路由原子性。
- 两侧滑动条各有 `node --test /data/user/0/com.deepseek.harness/files/dsh-local-fixes/{model-slider/model-slider.test.mjs,reasoning-slider/slider.test.mjs}`；真实运行时请重新打开或刷新现有 DSH Web 页，再切换模型确认当前滑动条显示与下一次请求的模型/等级一致。重启 DSH 引擎后，本 profile bundle 仍启用。
- 当前会话没有可连接的 Harness 页面，自动测试和 Host 激活检查不能代替页面视觉验收。没有使用额外的测试服务器或更改真实会话模型。

## 回滚

先在插件管理中停用 `@local/dsh-model-selection-fix` bundle：内置 `ui-model-selection` 的 disabled 覆盖随 bundle 卸载，两个滑动条仍按 `modelDirectories` 服务激活；刷新页面使 UI 加载恢复后的内置实现。请不要手动编辑 profile 的 `cordis.patch.yml`。下次 DSH 升级时需重新核对上游模型选择器接口及兼容性，再决定是否保留本替代包。
