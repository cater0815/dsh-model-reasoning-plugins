window.__ModuleLoader__.load({
  id: 'dsh-reasoning-slider',
  factory(require) {
    const React = require('react');
    const { createPortal } = require('react-dom');
    const h = React.createElement, NS = 'reasoning-slider';
    const zh = {
      title: '推理等级', compact: '推理', default: '默认', off: '关闭', minimal: '极低', low: '低', medium: '中', high: '高', xhigh: '超高', max: '最高',
      loading: '正在读取推理等级…', unsupported: '当前模型未提供推理等级', unavailable: '当前模型暂不可用',
      failed: '保存失败：{message}', retry: '重新读取', unknown: '当前值：{value}', collapse: '收起推理等级滑动条', expand: '展开推理等级滑动条',
    };
    const en = {
      title: 'Reasoning effort', compact: 'Effort', default: 'Default', off: 'Off', minimal: 'Minimal', low: 'Low', medium: 'Medium', high: 'High', xhigh: 'Extra high', max: 'Maximum',
      loading: 'Loading reasoning levels…', unsupported: 'This model provides no reasoning levels', unavailable: 'This model is currently unavailable',
      failed: 'Save failed: {message}', retry: 'Reload', unknown: 'Current value: {value}', collapse: 'Collapse reasoning slider', expand: 'Expand reasoning slider',
    };
    const known = new Set(['off', 'minimal', 'low', 'medium', 'high', 'xhigh', 'max']);
    function sliderState(state) {
      const current = state.current;
      const model = state.groups.find(group => group.id === current?.provider)?.models.find(model => model.id === current?.model);
      const reasoning = model?.reasoning;
      const levels = reasoning ? [
        ...(reasoning.defaultEffort === undefined ? [{ id: undefined, name: 'Default' }] : []),
        ...reasoning.efforts,
      ] : [];
      const effective = current?.reasoningEffort ?? reasoning?.defaultEffort;
      const index = levels.findIndex(level => level.id === effective);
      return { current, model, levels, index, effective, identity: JSON.stringify([current?.provider, current?.model, effective, levels.map(level => level.id)]) };
    }
    function indexAt(clientY, bounds, count) {
      if (count <= 1 || bounds.height <= 0) return 0;
      return Math.round(Math.max(0, Math.min(1, (clientY - bounds.top) / bounds.height)) * (count - 1));
    }
    function commitLevel(directory, identity, index, select) {
      const state = directory.store.getSnapshot(), view = sliderState(state);
      if (view.identity !== identity || state.pending !== null || !state.routable || !view.current || !view.levels[index]) return Promise.resolve({ skipped: true });
      if (view.index === index) return Promise.resolve({ unchanged: true });
      const { provider, model } = view.current, level = view.levels[index];
      const selection = { provider, model, ...(level.id === undefined ? {} : { reasoningEffort: level.id }) };
      return select ? select(selection) : directory.select(selection);
    }

    function floatingPosition(css = globalThis.CSS) {
      const safeLeft = 'max(8px, env(safe-area-inset-left, 0px))';
      return {
        position: 'fixed', left: css?.supports?.('left', safeLeft) ? safeLeft : '8px', right: 'auto',
        top: globalThis.matchMedia?.('(max-height:450px)')?.matches ? '50%' : '58%', bottom: 'auto',
        transform: 'translateY(-50%)', zIndex: 1050, width: '44px',
      };
    }
    function Slider({ directory, session, sessionId, available, select, t }) {
      const state = React.useSyncExternalStore(fn => directory.store.subscribe(fn), () => directory.store.getSnapshot());
      const sessionState = React.useSyncExternalStore(fn => session.subscribe(fn), () => session.getSnapshot());
      const view = sliderState(state), modelKey = JSON.stringify([view.current?.provider, view.current?.model]);
      const [draft, setDraft] = React.useState(null), [feedback, setFeedback] = React.useState(null);
      const [expanded, setExpanded] = React.useState(true), [peek, setPeek] = React.useState(false);
      const alive = React.useRef(true), token = React.useRef(0), saving = React.useRef(false);
      const gesture = React.useRef(null), suppressPeek = React.useRef(false);
      React.useEffect(() => {
        alive.current = true;
        if (available) directory.load().catch(() => {});
        return () => { alive.current = false; token.current++; saving.current = false; gesture.current = null; };
      }, [directory, sessionId, available]);
      React.useEffect(() => {
        token.current++; saving.current = false; gesture.current = null; suppressPeek.current = false;
        setDraft(null); setFeedback(null); setPeek(false);
      }, [directory, sessionId, modelKey]);
      React.useEffect(() => {
        if (gesture.current && gesture.current.identity !== view.identity) {
          gesture.current = null; suppressPeek.current = true; setPeek(false);
        }
        setDraft(previous => {
          if (!previous || previous.modelKey !== modelKey) return null;
          if (previous.phase === 'drag') return previous.identity === view.identity ? previous : null;
          return view.index === previous.index || previous.identity !== view.identity ? null : previous;
        });
      }, [view.identity, modelKey, view.index]);
      React.useEffect(() => {
        if (!available || sessionState.removed || typeof document.querySelectorAll !== 'function') return;
        const content = [...document.querySelectorAll('[data-conversation-content]')].find(element => element.getAttribute('data-conversation-session') === sessionId);
        if (!content) return;
        const before = content.getAttribute('data-reasoning-clearance');
        content.setAttribute('data-reasoning-clearance', 'true');
        return () => {
          if (before === null) content.removeAttribute('data-reasoning-clearance');
          else content.setAttribute('data-reasoning-clearance', before);
        };
      }, [sessionId, available, sessionState.removed]);
      if (!available || sessionState.removed) return null;
      const busy = state.pending !== null || saving.current;
      const loading = state.status === 'idle' || state.status === 'loading';
      const disabled = loading || !state.routable || view.levels.length < 2;
      const visibleDraft = draft?.modelKey === modelKey && (draft.phase !== 'drag' || draft.identity === view.identity) ? draft : null;
      const index = Math.max(0, Math.min(view.levels.length - 1, visibleDraft?.index ?? Math.max(0, view.index)));
      const position = view.levels.length < 2 ? 50 : index / (view.levels.length - 1) * 100;
      const label = level => level.id === undefined ? t('default') : known.has(level.id) ? t(level.id) : level.name;
      const valueLabel = !visibleDraft && view.index < 0 && view.effective !== undefined ? t('unknown', { value: view.effective }) : view.levels[index] ? label(view.levels[index]) : loading ? t('loading') : t('unsupported');
      async function save(nextIndex, identity) {
        if (disabled || busy || saving.current) return;
        const operation = ++token.current;
        saving.current = true;
        setDraft({ identity, modelKey, index: nextIndex, phase: 'saving' }); setFeedback(null);
        try {
          const result = await commitLevel(directory, identity, nextIndex, select);
          if (!alive.current || operation !== token.current) return;
          saving.current = false;
          if (result?.skipped || result?.unchanged) { setDraft(null); return; }
          if (!result?.ok) {
            setDraft(null); setFeedback({ error: true, text: t('failed', { message: result?.error?.message || 'Unknown error' }) }); return;
          }
          const actual = sliderState(directory.store.getSnapshot());
          setDraft(actual.index === nextIndex || actual.identity !== identity ? null : { identity, modelKey, index: nextIndex, phase: 'saved' });
        } catch (failure) {
          if (alive.current && operation === token.current) {
            saving.current = false; setDraft(null); setFeedback({ error: true, text: t('failed', { message: failure.message || String(failure) }) });
          }
        }
      }
      const hidePreview = () => { suppressPeek.current = true; setPeek(false); };
      const cancelDrag = () => { hidePreview(); if (!gesture.current) return; gesture.current = null; setDraft(null); };
      const preview = next => {
        if (!gesture.current || !view.levels[next]) return;
        setDraft({ identity: gesture.current.identity, modelKey, index: next, phase: 'drag' });
      };
      const note = feedback?.text || (!loading && !state.routable ? t('unavailable') : !loading && !view.levels.length ? t('unsupported') : state.error || '');
      return createPortal(h('aside', { className: 'dsh-reasoning-slider', style: floatingPosition(), 'data-expanded': expanded, 'data-model': view.current?.model, 'aria-label': t('title'),
        onMouseEnter: () => { if (!suppressPeek.current) setPeek(true); }, onMouseLeave: () => { suppressPeek.current = false; setPeek(false); } },
        h('button', { type: 'button', className: 'dsh-reasoning-slider-toggle', 'aria-expanded': expanded, 'aria-label': t(expanded ? 'collapse' : 'expand'),
          onClick: () => { cancelDrag(); setExpanded(value => !value); } }, t('compact')),
        expanded && h('div', { className: 'dsh-reasoning-slider-control', role: 'slider', tabIndex: 0,
          'aria-label': t('title'), 'aria-orientation': 'vertical', 'aria-valuemin': 0, 'aria-valuemax': Math.max(0, view.levels.length - 1),
          'aria-valuenow': index, 'aria-valuetext': valueLabel, 'aria-disabled': disabled || busy, 'data-dragging': Boolean(gesture.current), style: { '--effort-position': position + '%' },
          onFocus: () => { if (!suppressPeek.current) setPeek(true); }, onBlur: cancelDrag,
          onPointerDown: event => {
            if (disabled || busy) { event.preventDefault(); return; }
            suppressPeek.current = false; setPeek(true); event.preventDefault();
            event.currentTarget.focus({ preventScroll: true }); event.currentTarget.setPointerCapture?.(event.pointerId);
            const rect = event.currentTarget.getBoundingClientRect();
            gesture.current = { identity: view.identity, bounds: { top: rect.top + 12, height: Math.max(1, rect.height - 24) } };
            preview(indexAt(event.clientY, gesture.current.bounds, view.levels.length));
          },
          onPointerMove: event => { if (gesture.current) preview(indexAt(event.clientY, gesture.current.bounds, view.levels.length)); },
          onPointerUp: event => {
            hidePreview(); const drag = gesture.current; if (!drag) return; gesture.current = null;
            void save(indexAt(event.clientY, drag.bounds, view.levels.length), drag.identity);
          }, onPointerCancel: cancelDrag, onLostPointerCapture: cancelDrag,
          onKeyDown: event => {
            const moves = { ArrowUp: index - 1, ArrowLeft: index - 1, ArrowDown: index + 1, ArrowRight: index + 1, Home: 0, End: view.levels.length - 1, PageUp: index - 2, PageDown: index + 2 };
            if (!(event.key in moves)) return; event.preventDefault();
            suppressPeek.current = false; setPeek(true);
            void save(Math.max(0, Math.min(view.levels.length - 1, moves[event.key])), view.identity);
          } },
          h('div', { className: 'dsh-reasoning-slider-track', 'aria-hidden': true },
            h('div', { className: 'dsh-reasoning-slider-fill' }),
            view.levels.map((level, i) => h('span', { key: level.id ?? 'default', className: 'dsh-reasoning-slider-tick', 'data-active': i === index,
              style: { top: (view.levels.length < 2 ? 50 : i / (view.levels.length - 1) * 100) + '%' } })),
            h('div', { className: 'dsh-reasoning-slider-thumb' }))),
        expanded && h('div', { className: 'dsh-reasoning-slider-count', 'aria-hidden': true },
          h('span', { className: 'dsh-reasoning-slider-numerator' }, loading ? '…' : view.levels.length ? index + 1 : '—'),
          h('span', { className: 'dsh-reasoning-slider-denominator' }, view.levels.length)),
        expanded && (peek || visibleDraft?.phase === 'drag' || feedback?.error) && h('div', { className: 'dsh-reasoning-slider-label', role: feedback?.error ? 'alert' : undefined },
          h('strong', {}, valueLabel),
          note && h('span', { className: 'dsh-reasoning-slider-message', 'data-error': Boolean(feedback?.error || state.error) }, note),
          (feedback?.error || state.error) && h('button', { type: 'button', onClick: () => { setFeedback(null); directory.load().catch(() => {}); } }, t('retry')))), document.body);
    }
    const css = `
      .dsh-reasoning-slider{position:fixed;left:8px;left:max(8px,env(safe-area-inset-left,0px));right:auto;top:58%;bottom:auto;transform:translateY(-50%);z-index:1050;width:44px;box-sizing:border-box;border:0;border-radius:24px;background:transparent;box-shadow:none;backdrop-filter:none;color:var(--dsw-alias-label-primary,#243044);font-size:11px;user-select:none;-webkit-user-select:none;pointer-events:auto}
      .dsh-reasoning-slider[data-expanded=false]{border-radius:16px}
      .dsh-reasoning-slider-toggle{display:block;width:42px;height:34px;border:0;border-radius:22px;background:transparent;color:var(--dsh-reasoning-accent,#7397B3);font:inherit;font-weight:600;writing-mode:vertical-rl;text-orientation:mixed;padding:0;cursor:pointer}
      .dsh-reasoning-slider-control{position:relative;width:42px;height:clamp(130px,25dvh,220px);touch-action:none;cursor:ns-resize;outline:none}
      .dsh-reasoning-slider-control[data-dragging=true],.dsh-reasoning-slider-control:focus-visible{border-radius:12px;box-shadow:inset 0 0 0 2px var(--dsh-reasoning-accent,#7397B3)}
      .dsh-reasoning-slider-track{position:absolute;left:17px;width:8px;top:12px;bottom:12px;border-radius:5px;background:var(--dsw-alias-border-l1,#9aa6ba40)}
      .dsh-reasoning-slider-fill{position:absolute;inset:0 0 auto;height:var(--effort-position);border-radius:5px;background:var(--dsh-reasoning-accent,#7397B3)}
      .dsh-reasoning-slider-thumb{position:absolute;left:50%;top:var(--effort-position);transform:translate(-50%,-50%);width:22px;height:22px;border-radius:50%;background:var(--dsh-reasoning-accent,#7397B3);border:3px solid var(--dsw-alias-bg-layer-2,#fff);box-sizing:border-box;box-shadow:0 1px 5px #0003}
      .dsh-reasoning-slider-tick{position:absolute;left:-8px;width:3px;height:2px;transform:translateY(-50%);border-radius:1px;background:var(--dsw-alias-label-primary,#243044);opacity:.25}
      .dsh-reasoning-slider-tick[data-active=true]{background:var(--dsh-reasoning-accent,#7397B3);opacity:1}
      .dsh-reasoning-slider-count{display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;width:28px;height:38px;margin:0 auto;line-height:16px;font-size:10px;writing-mode:horizontal-tb;white-space:nowrap;color:var(--dsh-reasoning-accent,#7397B3)}
      .dsh-reasoning-slider-numerator{display:block;box-sizing:border-box;width:16px;border-bottom:1px solid currentColor;writing-mode:horizontal-tb}
      .dsh-reasoning-slider-denominator{display:block;width:100%;writing-mode:horizontal-tb}
      .dsh-reasoning-slider-label{position:absolute;left:0;top:auto;bottom:calc(100% + 8px);transform:none;width:max-content;max-width:min(260px,calc(100vw - 80px));box-sizing:border-box;padding:9px 12px;border:0;background:transparent;box-shadow:none;backdrop-filter:none;overflow-wrap:anywhere;display:flex;flex-direction:column;gap:4px;pointer-events:auto}
      .dsh-reasoning-slider-label{--preview-halo:var(--dsw-alias-bg-layer-2,#fff);line-height:1.5;text-shadow:-1px -1px 0 var(--preview-halo),0 -1px 0 var(--preview-halo),1px -1px 0 var(--preview-halo),-1px 0 0 var(--preview-halo),1px 0 0 var(--preview-halo),-1px 1px 0 var(--preview-halo),0 1px 0 var(--preview-halo),1px 1px 0 var(--preview-halo),0 0 3px var(--preview-halo)}
      .dsh-reasoning-slider-label strong{font-size:15px;color:var(--dsh-reasoning-accent,#7397B3);font-weight:700}
      .dsh-reasoning-slider-message{font-size:11px;line-height:1.4}
      .dsh-reasoning-slider-message[data-error=true]{color:#d95454}
      .dsh-reasoning-slider-label button{font:inherit;padding:4px 6px;border:0;color:inherit;background:transparent;cursor:pointer}
      /* 22px thumb: right edge = safe-left + 17 + 4 + 11; reading gap = 22 * 0.382 = 8.404px. */
      @media(max-width:760px){
        [data-conversation-content][data-reasoning-clearance=true]>[data-conversation-scroll]{box-sizing:border-box;padding-left:0!important}
        [data-conversation-content][data-reasoning-clearance=true] :has(>[data-chat-flow]){box-sizing:border-box;padding-left:48.404px!important;padding-left:calc(max(8px,env(safe-area-inset-left,0px)) + 32px + 8.404px)!important}
      }
      @media(max-height:450px){.dsh-reasoning-slider{top:50%}.dsh-reasoning-slider-control{height:120px}}
    `;
    function apply(ctx) {
      ctx.effect(() => ctx.locale.register(NS, { zh, en }), 'reasoning-slider: dictionaries');
      ctx.effect(() => { const style = document.createElement('style'); style.dataset.dshReasoningSlider = 'true'; style.textContent = css; document.head.appendChild(style); return () => style.remove(); }, 'reasoning-slider: styles');
      ctx.slots.inject('conversation.composer.dock', () => ctx.slots.register({
        name: 'conversation.composer.dock', id: 'reasoning-slider', locale: NS,
        inject: sessionId => {
          const directory = ctx.modelDirectories.directoryFor(sessionId);
          return { sessionId, directory, session: ctx.sessions.binding(sessionId).session,
            available: ctx.sessions.subagentAddress(sessionId) === undefined, select: selection => directory.select(selection) };
        },
      }, Slider));
    }
    return { apply, inject: ['slots', 'locale', 'modelDirectories', 'sessions'], sliderState, indexAt, commitLevel, floatingPosition, Slider };
  },
});
