import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import { test } from 'node:test';
const source = fs.readFileSync(new URL('./client.js', import.meta.url), 'utf8');
function load(react = {}, globals = {}) {
  let plugin;
  vm.runInNewContext(source, { ...globals, window: { __ModuleLoader__: { load(row) { plugin = row.factory(name => name === 'react-dom' ? { createPortal: node => node } : react); } } } });
  return plugin;
}
function fixture(reasoning = { efforts: ['off', 'low', 'medium', 'high', 'xhigh', 'max'].map(id => ({ id, name: id })) }) {
  let state = { current: { provider: 'openai011', model: 'gpt-6.1-sol', reasoningEffort: 'high' }, groups: [{ id: 'openai011', models: [{ id: 'gpt-6.1-sol', reasoning }, { id: 'other', reasoning: { efforts: [{ id: 'off', name: 'Off' }, { id: 'high', name: 'High' }] } }] }], pending: null, routable: true, status: 'ready', error: null };
  const calls = [];
  const directory = { store: { getSnapshot: () => state, subscribe: () => () => {} }, load: async () => state, select: async selection => { calls.push(selection); state = { ...state, current: selection }; return { ok: true }; } };
  return { directory, calls, get state() { return state; }, set state(value) { state = value; } };
}
const plain = value => JSON.parse(JSON.stringify(value));
function renderer(props, testDocument = { body: {} }) {
  const cells = [], cleanups = [], pending = []; let cursor = 0, tree;
  const react = {
    createElement: (tag, attrs, ...children) => ({ tag, attrs: attrs || {}, children: children.flat() }),
    useSyncExternalStore: (_subscribe, get) => { cursor++; return get(); },
    useState: initial => { const i = cursor++; if (!(i in cells)) cells[i] = initial; return [cells[i], value => { cells[i] = typeof value === 'function' ? value(cells[i]) : value; }]; },
    useRef: initial => { const i = cursor++; return cells[i] ??= { current: initial }; },
    useEffect: (fn, deps) => { const i = cursor++; if (!cells[i] || deps.some((d, j) => d !== cells[i][j])) { cells[i] = deps; pending.push(() => { cleanups[i]?.(); cleanups[i] = fn(); }); } },
  };
  const plugin = load(react, { document: testDocument });
  const render = () => { cursor = 0; tree = plugin.Slider(props); for (const effect of pending.splice(0)) effect(); return tree; };
  const nodes = node => !node || typeof node !== 'object' ? [] : [node, ...node.children.flatMap(nodes)];
  const find = predicate => nodes(tree).find(predicate);
  const slider = () => find(node => node.attrs.role === 'slider');
  const popup = () => find(node => node.attrs.className === 'dsh-reasoning-slider-label');
  const flush = async () => { await new Promise(setImmediate); render(); render(); };
  render(); render();
  return { render, find, slider, popup, flush, unmount: () => cleanups.forEach(fn => fn?.()) };
}
const event = (index, count = 7, key) => ({ clientY: 112 + index * 200 / Math.max(1, count - 1), key, pointerId: 0, preventDefault() {}, currentTarget: { focus() {}, setPointerCapture() {}, getBoundingClientRect: () => ({ top: 100, height: 224 }) } });
const propsOf = f => ({ directory: f.directory, session: { subscribe: () => () => {}, getSnapshot: () => ({ removed: false }) }, sessionId: 'test-session', available: true, t: (key, args) => key + (args?.message ? ':' + args.message : '') });

test('reading clearance follows its session and restores previous attributes on teardown', () => {
  const node = (id, before = null) => {
    const attrs = new Map([['data-conversation-session', id]]);
    if (before !== null) attrs.set('data-reasoning-clearance', before);
    return { getAttribute: key => attrs.get(key) ?? null, setAttribute: (key, value) => attrs.set(key, value), removeAttribute: key => attrs.delete(key) };
  };
  const first = node('test-session'), other = node('other-session', 'previous');
  const props = propsOf(fixture());
  const ui = renderer(props, { body: {}, querySelectorAll: () => [first, other] });
  assert.equal(first.getAttribute('data-reasoning-clearance'), 'true');
  assert.equal(other.getAttribute('data-reasoning-clearance'), 'previous');
  props.sessionId = 'other-session'; ui.render();
  assert.equal(first.getAttribute('data-reasoning-clearance'), null);
  assert.equal(other.getAttribute('data-reasoning-clearance'), 'true');
  ui.unmount(); assert.equal(other.getAttribute('data-reasoning-clearance'), 'previous');
});

test('reasoning rail remains on the left without injected styles', () => {
  const ui = renderer(propsOf(fixture()));
  const rail = ui.find(node => node.attrs.className === 'dsh-reasoning-slider');
  assert.ok(rail); assert.equal(rail.attrs.style.position, 'fixed'); assert.equal(rail.attrs.style.left, '8px');
  assert.equal(rail.attrs.style.right, 'auto'); assert.equal(rail.attrs.style.bottom, 'auto');
  assert.equal(rail.attrs.style.top, '58%'); assert.equal(rail.attrs.style.width, '44px'); ui.unmount();
});
test('left positioning handles legacy safe-area support and landscape', () => {
  const legacy = load({}, { CSS: { supports: () => false }, matchMedia: () => ({ matches: true }) }).floatingPosition();
  assert.equal(legacy.left, '8px'); assert.equal(legacy.top, '50%'); assert.equal(legacy.right, 'auto');
  const modern = load({}, { CSS: { supports: (property, value) => property === 'left' && value.includes('safe-area-inset-left') } }).floatingPosition();
  assert.match(modern.left, /safe-area-inset-left/); assert.equal(modern.bottom, 'auto');
});

test('advertised levels keep default separate from off', async () => {
  const { sliderState, commitLevel } = load(), f = fixture();
  assert.deepEqual(plain(sliderState(f.state).levels.map(l => l.id ?? 'default')), ['default', 'off', 'low', 'medium', 'high', 'xhigh', 'max']);
  await commitLevel(f.directory, sliderState(f.state).identity, 1);
  assert.deepEqual(plain(f.calls.at(-1)), { provider: 'openai011', model: 'gpt-6.1-sol', reasoningEffort: 'off' });
  await commitLevel(f.directory, sliderState(f.state).identity, 0); assert.equal('reasoningEffort' in f.calls.at(-1), false);
});
test('custom effort IDs and model defaults remain intact', async () => {
  const { sliderState, commitLevel } = load(), f = fixture({ defaultEffort: 'balanced', efforts: [{ id: 'balanced', name: 'Balanced' }, { id: 'deep', name: 'Deep' }] });
  f.state = { ...f.state, current: { provider: 'openai011', model: 'gpt-6.1-sol' } };
  assert.equal(sliderState(f.state).index, 0); await commitLevel(f.directory, sliderState(f.state).identity, 1); assert.equal(f.calls[0].reasoningEffort, 'deep');
});
test('stale model, changed capability and pending operation never save', async () => {
  const plugin = load(), f = fixture(), identity = plugin.sliderState(f.state).identity;
  f.state.groups[0].models[0].reasoning = { efforts: [{ id: 'high', name: 'High' }] };
  assert.equal((await plugin.commitLevel(f.directory, identity, 0)).skipped, true);
  f.state = { ...f.state, current: { provider: 'openai011', model: 'other' } };
  assert.equal((await plugin.commitLevel(f.directory, identity, 1)).skipped, true);
  f.state = { ...f.state, pending: {} }; assert.equal((await plugin.commitLevel(f.directory, plugin.sliderState(f.state).identity, 0)).skipped, true);
  assert.equal(f.calls.length, 0);
});
test('vertical mapping covers all levels and clamps endpoints', () => {
  const { indexAt } = load();
  for (let i = 0; i < 7; i++) assert.equal(indexAt(event(i).clientY, { top: 112, height: 200 }, 7), i);
  assert.equal(indexAt(-100, { top: 112, height: 200 }, 7), 0); assert.equal(indexAt(1000, { top: 112, height: 200 }, 7), 6);
});
test('vertical drag previews and saves exactly once on release; keyboard saves', async () => {
  const f = fixture(), ui = renderer(propsOf(f));
  assert.equal(ui.slider().attrs['aria-orientation'], 'vertical'); assert.equal(ui.find(n => n.tag === 'input'), undefined);
  ui.slider().attrs.onPointerDown(event(4)); ui.render(); ui.slider().attrs.onPointerMove(event(6)); ui.render();
  assert.equal(f.calls.length, 0); assert.equal(ui.slider().attrs['aria-valuetext'], 'max'); assert.ok(ui.popup());
  assert.equal(ui.slider().attrs['data-dragging'], true);
  ui.slider().attrs.onPointerUp(event(6)); ui.render(); assert.equal(ui.popup(), undefined); await ui.flush();
  assert.equal(ui.slider().attrs['data-dragging'], false);
  assert.equal(f.calls.length, 1); assert.equal(f.calls[0].reasoningEffort, 'max');
  ui.slider().attrs.onLostPointerCapture(); await ui.flush(); assert.equal(f.calls.length, 1);
  ui.slider().attrs.onKeyDown(event(0, 7, 'Home')); await ui.flush(); assert.equal('reasoningEffort' in f.calls[1], false); ui.unmount();
});
test('model changes and cancelled gestures never save the old selection', async () => {
  const f = fixture(), ui = renderer(propsOf(f));
  ui.slider().attrs.onPointerDown(event(4)); ui.render(); ui.slider().attrs.onPointerMove(event(6)); ui.render();
  f.state = { ...f.state, current: { provider: 'openai011', model: 'other' } }; ui.render(); ui.render();
  ui.slider().attrs.onPointerUp(event(1, 3)); await ui.flush(); assert.equal(f.calls.length, 0);
  ui.slider().attrs.onPointerDown(event(1, 3)); ui.render(); ui.slider().attrs.onPointerMove(event(0, 3)); ui.render();
  ui.slider().attrs.onPointerCancel(); ui.render(); ui.slider().attrs.onPointerUp(event(0, 3)); await ui.flush();
  assert.equal(f.calls.length, 0); assert.equal(ui.popup(), undefined); ui.unmount();
});
test('failure restores actual level; removed and subagent sessions hide control', async () => {
  const f = fixture(); f.directory.select = async () => ({ ok: false, error: { message: 'writer held' } });
  const props = propsOf(f), ui = renderer(props); ui.slider().attrs.onKeyDown(event(0, 7, 'End')); await ui.flush();
  assert.equal(ui.slider().attrs['aria-valuenow'], 4); assert.equal(ui.slider().attrs['aria-valuetext'], 'high'); assert.ok(ui.find(n => n.attrs.role === 'alert'));
  props.session.getSnapshot = () => ({ removed: true }); assert.equal(ui.render(), null);
  props.session.getSnapshot = () => ({ removed: false }); props.available = false; assert.equal(ui.render(), null); ui.unmount();
});
test('unsupported model cannot save and explains itself on focus', () => {
  const f = fixture(); f.state.groups[0].models[0].reasoning = undefined;
  const ui = renderer(propsOf(f)); assert.equal(ui.slider().attrs['aria-disabled'], true);
  ui.slider().attrs.onFocus(); ui.render(); assert.ok(ui.popup());
  ui.slider().attrs.onPointerDown(event(4)); ui.render(); ui.slider().attrs.onPointerUp(event(6)); ui.render();
  assert.equal(ui.popup(), undefined); assert.equal(f.calls.length, 0); ui.unmount();
});
test('release hides popup during delayed save, synthetic hover and late projection', async () => {
  const f = fixture(), props = propsOf(f); let resolve;
  props.select = () => new Promise(done => { resolve = done; }); const ui = renderer(props);
  ui.slider().attrs.onFocus(); ui.render(); ui.slider().attrs.onPointerDown(event(4)); ui.render(); ui.slider().attrs.onPointerMove(event(6)); ui.render(); assert.ok(ui.popup());
  ui.slider().attrs.onPointerUp(event(6)); ui.render(); assert.equal(ui.popup(), undefined); assert.equal(ui.slider().attrs['aria-valuenow'], 6);
  assert.equal(ui.slider().attrs['aria-disabled'], true);
  ui.find(n => n.attrs.className === 'dsh-reasoning-slider').attrs.onMouseEnter(); ui.slider().attrs.onFocus(); ui.render(); assert.equal(ui.popup(), undefined);
  ui.slider().attrs.onLostPointerCapture(); ui.render(); assert.equal(ui.slider().attrs['aria-valuenow'], 6);
  resolve({ ok: true }); await ui.flush(); assert.equal(ui.popup(), undefined); assert.equal(ui.slider().attrs['aria-valuenow'], 6);
  f.state = { ...f.state, current: { ...f.state.current, reasoningEffort: 'max' } }; ui.render(); ui.render(); assert.equal(ui.popup(), undefined);
  ui.slider().attrs.onPointerDown(event(6)); ui.render(); assert.ok(ui.popup()); ui.slider().attrs.onPointerCancel(); ui.render(); assert.equal(ui.popup(), undefined); ui.unmount();
});
test('direct effort save keeps model-menu loading state unchanged', async () => {
  const f = fixture(), plugin = load(); let selected;
  await plugin.commitLevel(f.directory, plugin.sliderState(f.state).identity, 6, async selection => { selected = selection; return { ok: true }; });
  assert.equal(selected.reasoningEffort, 'max'); assert.equal(f.calls.length, 0); assert.equal(f.state.pending, null); assert.equal(f.state.status, 'ready');
});
test('left floating rail and right popup are transparent with cyan title and left ticks', async () => {
  const f = fixture(), styles = [], effects = []; let seat, request;
  f.directory.select = async selection => { request = selection; return { ok: true }; };
  const plugin = load({}, { document: { createElement: () => ({ dataset: {}, remove() { styles.splice(styles.indexOf(this), 1); } }), head: { appendChild: style => styles.push(style) } } });
  plugin.apply({ effect(fn) { effects.push(fn()); }, locale: { register: () => () => {} },
    slots: { inject(name, fn) { assert.equal(name, 'conversation.composer.dock'); fn(); }, register(options) { seat = options; } },
    modelDirectories: { directoryFor: () => f.directory }, sessions: { binding: () => ({ session: propsOf(f).session }), subagentAddress: () => undefined },
  });
  const props = seat.inject('test-session'); await props.select({ provider: 'openai011', model: 'gpt-6.1-sol', reasoningEffort: 'max' });
  assert.deepEqual(plain(request), { provider: 'openai011', model: 'gpt-6.1-sol', reasoningEffort: 'max' });
  const css = styles[0].textContent, rail = css.match(/\.dsh-reasoning-slider\{([^}]+)\}/)[1], popup = css.match(/\.dsh-reasoning-slider-label\{([^}]+)\}/)[1];
  assert.match(rail, /position:fixed;left:8px;left:max\(8px/);
  assert.match(popup, /left:0;top:auto;bottom:calc\(100% \+ 8px\);transform:none/);
  assert.match(css, /padding-left:0!important/); assert.match(css, /32px \+ 8\.404px/);
  assert.equal(22 * 0.382, 8.404);
  for (const rule of [rail, popup]) { assert.match(rule, /background:transparent/); assert.match(rule, /border:0/); assert.match(rule, /box-shadow:none/); assert.match(rule, /backdrop-filter:none/); }
  const toggle = css.match(/\.dsh-reasoning-slider-toggle\{([^}]+)\}/)[1];
  assert.match(toggle, /writing-mode:vertical-rl/); assert.match(toggle, /color:var\(--dsh-reasoning-accent,#7397B3\)/);
  assert.match(css, /label strong\{font-size:15px;color:var\(--dsh-reasoning-accent,#7397B3\);font-weight:700/);
  assert.match(css, /text-shadow:-1px -1px 0 var\(--preview-halo\)/);
  assert.match(css, /control\[data-dragging=true\],\.dsh-reasoning-slider-control:focus-visible\{border-radius:12px;box-shadow:inset 0 0 0 2px/);
  assert.match(css, /tick\[data-active=true\]\{background:var\(--dsh-reasoning-accent,#7397B3\)/);
  const count = css.match(/\.dsh-reasoning-slider-count\{([^}]+)\}/)[1];
  assert.match(count, /color:var\(--dsh-reasoning-accent,#7397B3\)/);
  assert.match(count, /flex-direction:column/); assert.match(count, /writing-mode:horizontal-tb/); assert.match(count, /height:38px/);
  assert.match(css, /slider-numerator\{[^}]*border-bottom:1px solid currentColor/);
  const thumb = css.match(/\.dsh-reasoning-slider-thumb\{([^}]+)\}/)[1];
  assert.match(thumb, /width:22px;height:22px/); assert.match(thumb, /border:3px solid var\(--dsw-alias-bg-layer-2,#fff\)/); assert.match(thumb, /box-shadow:0 1px 5px #0003/);
  assert.match(css, /slider-tick\{position:absolute;left:-8px;/);
  effects.forEach(fn => fn?.()); assert.equal(styles.length, 0);
});

if (process.env.SLIDER_TEST_TOKEN) test('real engine persists every openai011 effort without LLM calls', async () => {
  const base = 'http://127.0.0.1:3099', auth = await fetch(base + '/?token=' + encodeURIComponent(process.env.SLIDER_TEST_TOKEN), { redirect: 'manual' });
  const cookie = auth.headers.get('set-cookie')?.split(';')[0]; assert.ok(cookie);
  const get = path => fetch(new URL(path, base), { headers: { cookie }, signal: AbortSignal.timeout(20000) });
  assert.equal((await get('/dsh-reasoning-slider/status.json')).status, 200); assert.equal((await get('/dsh-reasoning-slider/__nope__')).status, 404);
  const html = await (await get('/')).text(), marker = 'globalThis["__DSH_BOOT__"] = ';
  const graph = JSON.parse(html.slice(html.indexOf(marker) + marker.length).split('</script>')[0].trim().replace(/;$/, ''));
  const row = graph.entries.find(row => row.id === 'dsh-reasoning-slider'); assert.ok(row);
  const bundle = await (await get(row.url)).text(); assert.match(bundle, /createPortal/); assert.match(bundle, /position:fixed;left:8px;left:max/); assert.match(bundle, /aria-orientation.*vertical/);
  async function rpc(method, args) {
    const res = await fetch(base + '/api/' + method, { method: 'POST', headers: { cookie, 'Content-Type': 'application/json' }, body: JSON.stringify({ type: 'client-request', rpcId: crypto.randomUUID(), method, payload: { args } }), signal: AbortSignal.timeout(20000) });
    const body = await res.json(); assert.equal(body.result.ok, true, JSON.stringify(body.result.error)); return body.result.value;
  }
  const catalog = await rpc('session/modelCatalog', {}), route = catalog.groups.find(group => group.id === 'openai011'); assert.equal(route.models.length, 3);
  const { sessionId } = await rpc('session/create', { request: { cwd: '/data/user/0/com.deepseek.harness/files/dsh-local-fixes/reasoning-slider', agentPreset: 'standard' } });
  for (const model of route.models) for (const reasoningEffort of ['off', 'low', 'medium', 'high', 'xhigh', 'max', undefined]) {
    const selection = { sessionId, provider: route.id, model: model.id, ...(reasoningEffort === undefined ? {} : { reasoningEffort }) };
    const result = await rpc('session/selectModel', { request: selection }); assert.equal(result.selected.reasoningEffort, reasoningEffort);
    const projection = await rpc('session/projections', { request: { sessionId } });
    assert.equal(projection.values.modelSelection.next.reasoningEffort, reasoningEffort); assert.equal(projection.values.modelSelection.next.model, model.id);
  }
  console.log('Verified 21 durable reasoning selections; no LLM calls.');
});
