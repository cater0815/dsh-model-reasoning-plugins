window.__ModuleLoader__.load({
  id: 'dsh-model-slider',
  factory(require) {
    const React = require('react');
    const { createPortal } = require('react-dom');
    const h = React.createElement, NS = 'model-slider';
    const zh = { title: '模型', select: '滑动选择模型', collapse: '收起模型滑动条', expand: '展开模型滑动条', loading: '正在读取模型…', empty: '没有可用模型', unselected: '尚未选择模型', unavailable: '当前模型不在可用列表', failed: '切换失败：{message}', retry: '重新读取', partial: '部分提供方未加载成功', index: '{n} / {total}' };
    const en = { title: 'Model', select: 'Slide to select a model', collapse: 'Collapse model slider', expand: 'Expand model slider', loading: 'Loading models…', empty: 'No available models', unselected: 'No model selected', unavailable: 'Current model is unavailable', failed: 'Switch failed: {message}', retry: 'Reload', partial: 'Some providers could not be loaded', index: '{n} / {total}' };
    const keyOf = selection => selection ? JSON.stringify([selection.provider, selection.model]) : 'null';
    function modelView(state) {
      const rows = state.groups.flatMap(group => group.models.map(model => ({
        key: keyOf({ provider: group.id, model: model.id }), provider: group.id, providerName: group.name || group.id,
        model: model.id, name: model.name || model.id, reasoning: model.reasoning,
      })));
      const currentKey = keyOf(state.current);
      return { rows, currentKey, index: rows.findIndex(row => row.key === currentKey), catalogKey: JSON.stringify(rows.map(row => row.key)) };
    }
    function indexAt(clientY, bounds, count) {
      if (count <= 1 || bounds.height <= 0) return 0;
      const ratio = Math.max(0, Math.min(1, (clientY - bounds.top) / bounds.height));
      return Math.round(ratio * (count - 1));
    }
    function selectionFor(state, row) {
      const view = modelView(state);
      const from = view.rows[view.index];
      const effort = state.current?.reasoningEffort ?? from?.reasoning?.defaultEffort;
      const reasoningEffort = row.reasoning?.efforts.some(level => level.id === effort) ? effort : row.reasoning?.defaultEffort;
      return { provider: row.provider, model: row.model, ...(reasoningEffort === undefined ? {} : { reasoningEffort }) };
    }
    function commitModel(directory, sourceKey, catalogKey, index, select) {
      const state = directory.store.getSnapshot(), view = modelView(state), row = view.rows[index];
      if (view.currentKey !== sourceKey || view.catalogKey !== catalogKey || state.pending !== null || !row) return Promise.resolve({ skipped: true });
      if (row.key === view.currentKey) return Promise.resolve({ unchanged: true });
      return select(selectionFor(state, row));
    }

    function floatingPosition(css = globalThis.CSS) {
      const safeRight = 'max(8px, env(safe-area-inset-right, 0px))';
      return {
        position: 'fixed', left: 'auto', right: css?.supports?.('right', safeRight) ? safeRight : '8px',
        top: globalThis.matchMedia?.('(max-height:450px)')?.matches ? '50%' : '58%', bottom: 'auto', transform: 'translateY(-50%)', zIndex: 1050, width: '44px',
      };
    }
    function ModelSlider({ directory, session, sessionId, available, select, t }) {
      const state = React.useSyncExternalStore(fn => directory.store.subscribe(fn), () => directory.store.getSnapshot());
      const sessionState = React.useSyncExternalStore(fn => session.subscribe(fn), () => session.getSnapshot());
      const view = modelView(state);
      const [draft, setDraft] = React.useState(null), [error, setError] = React.useState(null);
      const [expanded, setExpanded] = React.useState(true), [peek, setPeek] = React.useState(false);
      const suppressPeek = React.useRef(false);
      const gesture = React.useRef(null), saving = React.useRef(false), alive = React.useRef(true), sequence = React.useRef(0);
      React.useEffect(() => {
        alive.current = true;
        if (available) directory.load().catch(() => {});
        return () => { alive.current = false; saving.current = false; gesture.current = null; sequence.current++; };
      }, [directory, sessionId, available]);
      React.useEffect(() => {
        saving.current = false; gesture.current = null; suppressPeek.current = false; sequence.current++;
        setDraft(null); setError(null); setPeek(false);
      }, [directory, sessionId]);
      React.useEffect(() => {
        setDraft(previous => {
          if (!previous) return null;
          if (previous.catalogKey !== view.catalogKey || (view.currentKey !== previous.sourceKey && view.currentKey !== previous.targetKey)) {
            gesture.current = null; saving.current = false; sequence.current++; return null;
          }
          if (previous.phase === 'drag' && view.currentKey !== previous.sourceKey) { gesture.current = null; return null; }
          return previous.phase !== 'drag' && view.currentKey === previous.targetKey ? null : previous;
        });
      }, [view.currentKey, view.catalogKey]);
      React.useEffect(() => {
        if (!available || sessionState.removed || typeof document.querySelectorAll !== 'function') return;
        const content = [...document.querySelectorAll('[data-conversation-content]')].find(element => element.getAttribute('data-conversation-session') === sessionId);
        if (!content) return;
        const before = content.getAttribute('data-model-clearance');
        content.setAttribute('data-model-clearance', 'true');
        return () => {
          if (before === null) content.removeAttribute('data-model-clearance');
          else content.setAttribute('data-model-clearance', before);
        };
      }, [sessionId, available, sessionState.removed]);
      if (!available || sessionState.removed) return null;
      const loading = state.status === 'loading' || state.status === 'idle';
      const disabled = loading || view.rows.length === 0 || (view.rows.length === 1 && view.index === 0);
      const busy = saving.current || state.pending !== null;
      const activeDraft = draft?.catalogKey === view.catalogKey && view.rows.some(row => row.key === draft.targetKey) && (view.currentKey === draft.sourceKey || view.currentKey === draft.targetKey) ? draft : null;
      const index = activeDraft ? view.rows.findIndex(row => row.key === activeDraft.targetKey) : Math.max(0, view.index);
      const hasSelection = Boolean(activeDraft) || view.index >= 0;
      const row = hasSelection ? view.rows[index] : undefined;
      const position = view.rows.length < 2 ? 50 : index / (view.rows.length - 1) * 100;
      const modelName = row ? `${row.providerName} · ${row.name}` : state.current ? `${state.current.provider} · ${state.current.model}` : loading ? t('loading') : view.rows.length ? t('unselected') : t('empty');
      const preview = next => {
        const drag = gesture.current;
        if (!drag || !view.rows[next]) return;
        drag.index = next;
        setDraft({ ...drag, targetKey: view.rows[next].key, phase: 'drag' });
      };
      async function save(next, sourceKey = view.currentKey, catalogKey = view.catalogKey) {
        if (disabled || busy || saving.current || !view.rows[next]) return;
        const operation = ++sequence.current, targetKey = view.rows[next].key;
        saving.current = true;
        setError(null); setDraft({ sourceKey, catalogKey, targetKey, phase: 'saving' });
        try {
          const result = await commitModel(directory, sourceKey, catalogKey, next, select);
          if (!alive.current || operation !== sequence.current) return;
          saving.current = false;
          if (result?.skipped || result?.unchanged) { setDraft(null); return; }
          if (!result?.ok) { setDraft(null); setError(t('failed', { message: result?.error?.message || 'Unknown error' })); return; }
          const actual = modelView(directory.store.getSnapshot());
          setDraft(actual.currentKey === targetKey || actual.currentKey !== sourceKey ? null : { sourceKey, catalogKey, targetKey, phase: 'saved' });
        } catch (failure) {
          if (alive.current && operation === sequence.current) { saving.current = false; setDraft(null); setError(t('failed', { message: failure.message || String(failure) })); }
        }
      }
      const boundsOf = element => { const rect = element.getBoundingClientRect(); return { top: rect.top + 12, height: Math.max(1, rect.height - 24) }; };
      const hidePreview = () => { suppressPeek.current = true; setPeek(false); };
      const cancel = () => { hidePreview(); if (!gesture.current) return; gesture.current = null; setDraft(null); };
      const message = error || state.error || (state.failures?.length ? t('partial') : !loading && state.current && view.index < 0 ? t('unavailable') : '');
      return createPortal(h('aside', { className: 'dsh-model-slider', style: floatingPosition(), 'data-expanded': expanded, 'aria-label': t('select'), onMouseEnter: () => { if (!suppressPeek.current) setPeek(true); }, onMouseLeave: () => { suppressPeek.current = false; setPeek(false); } },
        h('button', { type: 'button', className: 'dsh-model-slider-toggle', 'aria-label': t(expanded ? 'collapse' : 'expand'), 'aria-expanded': expanded,
          onClick: () => { cancel(); setExpanded(value => !value); } }, t('title')),
        expanded && h('div', { className: 'dsh-model-slider-control', role: 'slider', tabIndex: 0,
          'aria-label': t('select'), 'aria-orientation': 'vertical', 'aria-valuemin': 0, 'aria-valuemax': Math.max(0, view.rows.length - 1),
          'aria-valuenow': index, 'aria-valuetext': modelName, 'aria-disabled': disabled || busy, 'data-dragging': Boolean(gesture.current),
          onFocus: () => { if (!suppressPeek.current) setPeek(true); }, onBlur: () => { setPeek(false); cancel(); },
          onPointerDown: event => {
            if (disabled || busy) { event.preventDefault(); return; }
            suppressPeek.current = false; setPeek(true);
            event.preventDefault(); event.currentTarget.focus({ preventScroll: true }); event.currentTarget.setPointerCapture?.(event.pointerId);
            gesture.current = { sourceKey: view.currentKey, catalogKey: view.catalogKey, index, bounds: boundsOf(event.currentTarget) };
            preview(indexAt(event.clientY, gesture.current.bounds, view.rows.length));
          },
          onPointerMove: event => { if (gesture.current) preview(indexAt(event.clientY, gesture.current.bounds, view.rows.length)); },
          onPointerUp: event => {
            hidePreview();
            const drag = gesture.current; if (!drag) return; gesture.current = null;
            void save(indexAt(event.clientY, drag.bounds, view.rows.length), drag.sourceKey, drag.catalogKey);
          }, onPointerCancel: cancel, onLostPointerCapture: cancel,
          onKeyDown: event => {
            const moves = { ArrowUp: index - 1, ArrowLeft: index - 1, ArrowDown: index + 1, ArrowRight: index + 1, Home: 0, End: view.rows.length - 1, PageUp: index - 5, PageDown: index + 5 };
            if (!(event.key in moves)) return; event.preventDefault();
            suppressPeek.current = false; setPeek(true);
            void save(Math.max(0, Math.min(view.rows.length - 1, moves[event.key])));
          },
          style: { '--model-position': position + '%' } },
          h('div', { className: 'dsh-model-slider-track', 'aria-hidden': true },
            h('div', { className: 'dsh-model-slider-fill' }),
            view.rows.length <= 40 && view.rows.map((item, i) => h('span', { key: item.key, className: 'dsh-model-slider-tick', 'data-active': hasSelection && i === index, style: { top: (view.rows.length < 2 ? 50 : i / (view.rows.length - 1) * 100) + '%' } })),
            hasSelection && h('div', { className: 'dsh-model-slider-thumb' }))),
        expanded && h('div', { className: 'dsh-model-slider-count', 'aria-hidden': true },
          h('span', { className: 'dsh-model-slider-numerator' }, loading ? '…' : view.index < 0 && !activeDraft ? '–' : index + 1),
          h('span', { className: 'dsh-model-slider-denominator' }, view.rows.length)),
        expanded && (peek || draft?.phase === 'drag' || error) && h('div', { className: 'dsh-model-slider-label', 'data-error': Boolean(error || state.error), role: error ? 'alert' : undefined },
          row && h('span', { className: 'dsh-model-slider-provider' }, row.providerName),
          h('strong', {}, row?.name || modelName),
          message && h('span', { className: 'dsh-model-slider-message' }, message),
          (error || state.error || !view.rows.length) && h('button', { type: 'button', onClick: () => { setError(null); directory.load().catch(() => {}); } }, t('retry')))), document.body);
    }
    const css = `
      .dsh-model-slider{position:fixed;left:auto;right:8px;right:max(8px,env(safe-area-inset-right,0px));top:58%;bottom:auto;transform:translateY(-50%);z-index:1050;width:44px;box-sizing:border-box;border:0;border-radius:24px;background:transparent;color:var(--dsw-alias-label-primary,#243044);box-shadow:none;backdrop-filter:none;font-size:11px;user-select:none;-webkit-user-select:none;pointer-events:auto}
      .dsh-model-slider[data-expanded=false]{border-radius:16px}
      .dsh-model-slider-toggle{display:block;width:42px;height:34px;border:0;border-radius:22px;background:transparent;color:var(--dsw-alias-brand-primary,#4b76e5);font:inherit;font-weight:600;writing-mode:vertical-rl;text-orientation:mixed;padding:0;cursor:pointer}
      .dsh-model-slider-control{position:relative;width:42px;height:clamp(130px,25dvh,220px);touch-action:none;cursor:ns-resize;outline:none}
      .dsh-model-slider-control[data-dragging=true],.dsh-model-slider-control:focus-visible{border-radius:12px;box-shadow:inset 0 0 0 2px var(--dsw-alias-brand-primary,#4b76e5)}
      .dsh-model-slider-track{position:absolute;left:17px;width:8px;top:12px;bottom:12px;border-radius:5px;background:var(--dsw-alias-border-l1,#9aa6ba40)}
      .dsh-model-slider-fill{position:absolute;inset:0 0 auto;height:var(--model-position);border-radius:5px;background:var(--dsw-alias-brand-primary,#4b76e5)}
      .dsh-model-slider-thumb{position:absolute;left:50%;top:var(--model-position);transform:translate(-50%,-50%);width:22px;height:22px;border-radius:50%;background:var(--dsw-alias-brand-primary,#4b76e5);border:3px solid var(--dsw-alias-bg-layer-2,#fff);box-sizing:border-box;box-shadow:0 1px 5px #0003}
      .dsh-model-slider-tick{position:absolute;left:11px;width:3px;height:2px;transform:translateY(-50%);border-radius:1px;background:var(--dsw-alias-label-primary,#243044);opacity:.25}
      .dsh-model-slider-tick[data-active=true]{background:var(--dsw-alias-brand-primary,#4b76e5);opacity:1;z-index:1}
      .dsh-model-slider-count{display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;width:28px;height:38px;margin:0 auto;line-height:16px;font-size:10px;writing-mode:horizontal-tb;white-space:nowrap;color:var(--dsw-alias-brand-primary,#4b76e5)}
      .dsh-model-slider-numerator{display:block;box-sizing:border-box;width:16px;border-bottom:1px solid currentColor;writing-mode:horizontal-tb}
      .dsh-model-slider-denominator{display:block;width:100%;writing-mode:horizontal-tb}
      .dsh-model-slider-label{position:absolute;right:0;top:auto;bottom:calc(100% + 8px);transform:none;width:max-content;max-width:min(260px,calc(100vw - 80px));box-sizing:border-box;padding:9px 12px;border-radius:12px;border:0;background:transparent;box-shadow:none;backdrop-filter:none;overflow-wrap:anywhere;display:flex;flex-direction:column;gap:4px;pointer-events:auto}
      .dsh-model-slider-label{--preview-halo:var(--dsw-alias-bg-layer-2,#fff);line-height:1.5;text-shadow:-1px -1px 0 var(--preview-halo),0 -1px 0 var(--preview-halo),1px -1px 0 var(--preview-halo),-1px 0 0 var(--preview-halo),1px 0 0 var(--preview-halo),-1px 1px 0 var(--preview-halo),0 1px 0 var(--preview-halo),1px 1px 0 var(--preview-halo),0 0 3px var(--preview-halo)}
      .dsh-model-slider-provider{font-size:12px;font-weight:600;color:var(--dsw-alias-label-primary,#243044)}
      .dsh-model-slider-label strong{font-size:15px;color:var(--dsw-alias-brand-primary,#4b76e5);font-weight:700}
      .dsh-model-slider-message{font-size:11px;line-height:1.4}
      .dsh-model-slider-label[data-error=true] .dsh-model-slider-message{color:#d95454}
      .dsh-model-slider-label button{font:inherit;padding:4px 6px;border:1px solid #8884;border-radius:5px;color:inherit;background:transparent;cursor:pointer}
      /* 44px rail, thumb centre at 21px, radius 11px: inward edge = safe-right + 34px. */
      @media(max-width:760px){
        [data-conversation-content][data-model-clearance=true]>[data-conversation-scroll]{box-sizing:border-box;padding-right:0!important}
        [data-conversation-content][data-model-clearance=true] :has(>[data-chat-flow]){box-sizing:border-box;padding-right:50.404px!important;padding-right:calc(max(8px,env(safe-area-inset-right,0px)) + 34px + 8.404px)!important}
      }
      @media(max-height:450px){.dsh-model-slider{top:50%}.dsh-model-slider-control{height:120px}}
    `;
    function apply(ctx) {
      ctx.effect(() => ctx.locale.register(NS, { zh, en }), 'model-slider: dictionaries');
      ctx.effect(() => { const style = document.createElement('style'); style.dataset.dshModelSlider = 'true'; style.textContent = css; document.head.appendChild(style); return () => style.remove(); }, 'model-slider: styles');
      ctx.slots.inject('conversation.composer.dock', () => ctx.slots.register({
        name: 'conversation.composer.dock', id: 'model-slider', locale: NS,
        inject: sessionId => {
          const directory = ctx.modelDirectories.directoryFor(sessionId);
          return { sessionId, directory, session: ctx.sessions.binding(sessionId).session,
            available: ctx.sessions.subagentAddress(sessionId) === undefined, select: selection => directory.select(selection) };
        },
      }, ModelSlider));
    }
    return { apply, inject: ['slots', 'locale', 'modelDirectories', 'sessions'], modelView, indexAt, selectionFor, commitModel, floatingPosition, ModelSlider };
  },
});
