import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import { test } from 'node:test';
const source = fs.readFileSync(new URL('./client.js', import.meta.url), 'utf8');
function load(react = {}, globals = {}) {
  let plugin;
  vm.runInNewContext(source, { ...globals, window: { __ModuleLoader__: { load(row) { plugin = row.factory(name => name === 'react-dom' ? { createPortal: node => node } : react); } } } });
  return plugin;
}
const plain = value => JSON.parse(JSON.stringify(value));
const effort = { efforts: [{ id: 'off', name: 'Off' }, { id: 'high', name: 'High' }] };
function fixture() {
  let state = { current: { provider: 'openai', model: 'shared', reasoningEffort: 'high' }, groups: [
    { id: 'openai', name: 'OpenAI', models: [{ id: 'shared', name: 'Shared', reasoning: effort }, { id: 'other', name: 'Other', reasoning: effort }] },
    { id: 'anthropic', name: 'Claude', models: [{ id: 'claude', name: 'Claude', reasoning: { defaultEffort: 'medium', efforts: [{ id: 'medium', name: 'Medium' }] } }] },
    { id: 'openai011', name: 'openai011', models: [{ id: 'shared', name: 'Shared', reasoning: effort }] },
    { id: 'plain', name: 'Plain', models: [{ id: 'plain', name: 'Plain' }] },
  ], pending: null, status: 'ready', error: null, failures: [], routable: true };
  const calls = [];
  const directory = { store: { getSnapshot: () => state, subscribe: () => () => {} }, load: async () => state };
  const select = async selection => { calls.push(selection); state = { ...state, current: selection }; return { ok: true }; };
  return { directory, calls, select, get state() { return state; }, set state(value) { state = value; } };
}
function renderer(props) {
  const cells = [], cleanups = [], pending = []; let cursor = 0, tree;
  const react = {
    createElement: (tag, attrs, ...children) => ({ tag, attrs: attrs || {}, children: children.flat() }),
    useSyncExternalStore: (_subscribe, get) => { cursor++; return get(); },
    useState: initial => { const i = cursor++; if (!(i in cells)) cells[i] = initial; return [cells[i], value => { cells[i] = typeof value === 'function' ? value(cells[i]) : value; }]; },
    useRef: initial => { const i = cursor++; return cells[i] ??= { current: initial }; },
    useEffect: (fn, deps) => { const i = cursor++; if (!cells[i] || deps.some((d, j) => d !== cells[i][j])) { cells[i] = deps; pending.push(() => { cleanups[i]?.(); cleanups[i] = fn(); }); } },
  };
  const plugin = load(react, { document: { body: {} } });
  const render = () => { cursor = 0; tree = plugin.ModelSlider(props); for (const effect of pending.splice(0)) effect(); return tree; };
  const nodes = node => !node || typeof node !== 'object' ? [] : [node, ...node.children.flatMap(nodes)];
  const find = predicate => nodes(tree).find(predicate);
  const slider = () => find(node => node.attrs.role === 'slider');
  const flush = async () => { await new Promise(setImmediate); render(); render(); };
  render(); render();
  return { render, find, slider, flush, unmount: () => cleanups.forEach(fn => fn?.()) };
}
const event = (clientY, key) => ({ clientY, key, pointerId: 0, preventDefault() {}, currentTarget: { focus() {}, setPointerCapture() {}, getBoundingClientRect: () => ({ top: 100, height: 224 }) } });
const propsOf = f => ({ directory: f.directory, session: { subscribe: () => () => {}, getSnapshot: () => ({ removed: false }) }, sessionId: 'test-session', available: true, select: f.select, t: (key, args) => key + (args?.message ? ':' + args.message : '') });

test('model rail stays fixed on the right without an injected stylesheet', () => {
  const ui = renderer(propsOf(fixture()));
  const rail = ui.find(node => node.attrs.className === 'dsh-model-slider');
  assert.equal(rail.attrs.style.position, 'fixed');
  assert.equal(rail.attrs.style.right, '8px');
  assert.equal(rail.attrs.style.left, 'auto'); assert.equal(rail.attrs.style.bottom, 'auto');
  assert.equal(rail.attrs.style.top, '58%'); assert.equal(rail.attrs.style.width, '44px');
  ui.unmount();
});
test('right positioning handles unsupported safe-area CSS and landscape screens', () => {
  const legacy = load({}, { CSS: { supports: () => false }, matchMedia: () => ({ matches: true }) }).floatingPosition();
  assert.equal(legacy.right, '8px'); assert.equal(legacy.top, '50%');
  const modern = load({}, { CSS: { supports: (property, value) => property === 'right' && value.includes('safe-area-inset-right') } }).floatingPosition();
  assert.match(modern.right, /safe-area-inset-right/); assert.equal(modern.left, 'auto'); assert.equal(modern.bottom, 'auto');
});

test('lists every provider and distinguishes duplicate model IDs', () => {
  const f = fixture(), view = load().modelView(f.state);
  assert.equal(view.rows.length, 5); assert.equal(new Set(view.rows.map(row => row.key)).size, 5);
  assert.equal(view.rows[0].model, view.rows[3].model); assert.notEqual(view.rows[0].key, view.rows[3].key);
});
test('unselected state does not pretend the first model is selected', () => {
  const f = fixture();
  f.state = { ...f.state, current: null };
  const ui = renderer(propsOf(f));
  assert.equal(ui.slider().attrs['aria-valuetext'], 'unselected');
  assert.notEqual(ui.slider().attrs['aria-disabled'], true);
  ui.slider().attrs.onKeyDown(event(0, 'End'));
  assert.equal(f.calls.length, 1);
  assert.deepEqual(plain(f.calls[0]), { provider: 'plain', model: 'plain' });
  ui.unmount();
});
test('vertical mapping clamps endpoints and steps across all rows', () => {
  const { indexAt } = load();
  for (let i = 0; i < 100; i++) assert.equal(indexAt(20 + i * 10, { top: 20, height: 990 }, 100), i);
  assert.equal(indexAt(-100, { top: 20, height: 200 }, 5), 0); assert.equal(indexAt(1000, { top: 20, height: 200 }, 5), 4);
  assert.equal(indexAt(1000, { top: 20, height: 0 }, 1), 0);
});
test('preserves compatible reasoning and falls back safely', () => {
  const f = fixture(), plugin = load(), rows = plugin.modelView(f.state).rows;
  assert.equal(plugin.selectionFor(f.state, rows[3]).reasoningEffort, 'high');
  assert.equal(plugin.selectionFor(f.state, rows[2]).reasoningEffort, 'medium');
  assert.equal('reasoningEffort' in plugin.selectionFor(f.state, rows[4]), false);
});
test('stale catalog, changed source and pending operation never write', async () => {
  const f = fixture(), plugin = load(), view = plugin.modelView(f.state);
  assert.equal((await plugin.commitModel(f.directory, view.currentKey, 'stale', 3, f.select)).skipped, true);
  f.state = { ...f.state, current: { provider: 'plain', model: 'plain' } };
  assert.equal((await plugin.commitModel(f.directory, view.currentKey, view.catalogKey, 3, f.select)).skipped, true);
  f.state = { ...f.state, pending: {} };
  assert.equal((await plugin.commitModel(f.directory, plugin.modelView(f.state).currentKey, view.catalogKey, 3, f.select)).skipped, true);
  assert.equal(f.calls.length, 0);
});
test('pointer previews all models and saves only once on release', async () => {
  const f = fixture(), ui = renderer(propsOf(f));
  ui.slider().attrs.onPointerDown(event(112)); ui.render(); ui.slider().attrs.onPointerMove(event(262)); ui.render();
  assert.equal(ui.slider().attrs['aria-valuenow'], 3); assert.match(ui.slider().attrs['aria-valuetext'], /openai011/); assert.equal(f.calls.length, 0);
  assert.equal(ui.slider().attrs['data-dragging'], true);
  assert.equal(ui.find(node => node.attrs.className === 'dsh-model-slider-tick' && node.attrs['data-active']).attrs.key, JSON.stringify(['openai011', 'shared']));
  ui.slider().attrs.onPointerUp(event(262)); await ui.flush();
  assert.equal(ui.slider().attrs['data-dragging'], false);
  assert.equal(f.calls.length, 1); assert.deepEqual(plain(f.calls[0]), { provider: 'openai011', model: 'shared', reasoningEffort: 'high' });
  ui.slider().attrs.onLostPointerCapture(); ui.render(); assert.equal(ui.slider().attrs['aria-valuenow'], 3); assert.equal(f.calls.length, 1); ui.unmount();
});
test('cancelled gestures and model changes during a drag do not save', async () => {
  const f = fixture(), ui = renderer(propsOf(f));
  ui.slider().attrs.onPointerDown(event(112)); ui.render(); ui.slider().attrs.onPointerMove(event(312)); ui.render();
  ui.slider().attrs.onPointerCancel(); ui.render(); ui.slider().attrs.onPointerUp(event(312)); await ui.flush(); assert.equal(f.calls.length, 0);
  ui.slider().attrs.onPointerDown(event(112)); ui.render();
  f.state = { ...f.state, current: { provider: 'plain', model: 'plain' } }; ui.render(); ui.render();
  ui.slider().attrs.onPointerUp(event(262)); await ui.flush(); assert.equal(f.calls.length, 0); ui.unmount();
});
test('keyboard traverses models, supports endpoints and collapsed control', async () => {
  const f = fixture(), ui = renderer(propsOf(f));
  ui.slider().attrs.onKeyDown(event(0, 'End')); await ui.flush(); assert.equal(f.calls[0].model, 'plain');
  ui.slider().attrs.onKeyDown(event(0, 'Home')); await ui.flush(); assert.equal(f.calls[1].provider, 'openai');
  ui.find(n => n.attrs.className === 'dsh-model-slider-toggle').attrs.onClick(); ui.render(); assert.equal(ui.slider(), undefined); ui.unmount();
});
test('release hides preview immediately while delayed save keeps position', async () => {
  const f = fixture(), props = propsOf(f); let resolve;
  props.select = () => new Promise(done => { resolve = done; }); const ui = renderer(props);
  const popup = () => ui.find(n => n.attrs.className === 'dsh-model-slider-label');
  ui.slider().attrs.onFocus(); ui.render();
  ui.slider().attrs.onPointerDown(event(112)); ui.render(); ui.slider().attrs.onPointerMove(event(262)); ui.render();
  assert.ok(popup());
  ui.slider().attrs.onPointerUp(event(262)); ui.render();
  assert.equal(popup(), undefined);
  assert.equal(ui.slider().attrs['aria-valuenow'], 3); assert.equal(ui.slider().attrs['aria-disabled'], true);
  ui.find(n => n.attrs.className === 'dsh-model-slider').attrs.onMouseEnter();
  ui.slider().attrs.onFocus(); ui.render(); assert.equal(popup(), undefined);
  ui.slider().attrs.onLostPointerCapture(); ui.render(); assert.equal(popup(), undefined); assert.equal(ui.slider().attrs['aria-valuenow'], 3);
  resolve({ ok: true }); await ui.flush(); assert.equal(popup(), undefined); assert.equal(ui.slider().attrs['aria-valuenow'], 3);
  f.state = { ...f.state, current: { provider: 'openai011', model: 'shared', reasoningEffort: 'high' } }; ui.render(); ui.render();
  assert.equal(popup(), undefined); assert.equal(ui.slider().attrs['aria-valuenow'], 3); assert.equal(f.state.pending, null);
  ui.slider().attrs.onPointerDown(event(262)); ui.render(); assert.ok(popup());
  ui.slider().attrs.onPointerCancel(); ui.render(); assert.equal(popup(), undefined);
  ui.unmount();
});
test('errors restore actual model; removed and subagent sessions hide control', async () => {
  const f = fixture(), props = propsOf(f); props.select = async () => ({ ok: false, error: { message: 'writer held' } });
  const ui = renderer(props); ui.slider().attrs.onKeyDown(event(0, 'End')); await ui.flush();
  assert.equal(ui.slider().attrs['aria-valuenow'], 0); assert.ok(ui.find(n => n.attrs.role === 'alert'));
  props.available = false; assert.equal(ui.render(), null);
  props.available = true; props.session.getSnapshot = () => ({ removed: true }); assert.equal(ui.render(), null); ui.unmount();
});
test('plugin mounts a session portal, shares directory selection and cleans styles', async () => {
  const f = fixture(), styles = [], effects = []; let seat, request;
  f.directory.select = async selection => { request = selection; return { ok: true }; };
  const plugin = load({}, { document: { createElement: () => ({ dataset: {}, remove() { styles.splice(styles.indexOf(this), 1); } }), head: { appendChild: style => styles.push(style) } } });
  plugin.apply({ effect(fn) { effects.push(fn()); }, locale: { register: () => () => {} },
    slots: { inject(name, fn) { assert.equal(name, 'conversation.composer.dock'); fn(); }, register(options) { seat = options; } },
    modelDirectories: { directoryFor: () => f.directory }, sessions: { binding: () => ({ session: propsOf(f).session }), subagentAddress: () => undefined },
  });
  const props = seat.inject('test-session'); await props.select({ provider: 'plain', model: 'plain' });
  assert.deepEqual(plain(request), { provider: 'plain', model: 'plain' });
  const css = styles[0].textContent;
  assert.match(css, /position:fixed/); assert.match(css, /touch-action:none/);
  const rail = css.match(/\.dsh-model-slider\{([^}]+)\}/)[1];
  const popup = css.match(/\.dsh-model-slider-label\{([^}]+)\}/)[1];
  const thumb = css.match(/\.dsh-model-slider-thumb\{([^}]+)\}/)[1];
  assert.match(rail, /background:transparent/); assert.match(rail, /border:0/); assert.match(rail, /box-shadow:none/);
  assert.match(thumb, /border:3px solid var\(--dsw-alias-bg-layer-2,#fff\)/);
  assert.match(popup, /background:transparent/); assert.match(popup, /border:0/); assert.match(popup, /box-shadow:none/);
  assert.match(popup, /right:0;top:auto;bottom:calc\(100% \+ 8px\);transform:none/);
  assert.match(css, /padding-right:0!important/); assert.match(css, /34px \+ 8\.404px/);
  assert.match(css, /slider-tick\[data-active=true\]\{background:var\(--dsw-alias-brand-primary,#4b76e5\);opacity:1/);
  const toggle = css.match(/\.dsh-model-slider-toggle\{([^}]+)\}/)[1];
  assert.match(toggle, /writing-mode:vertical-rl/); assert.match(toggle, /color:var\(--dsw-alias-brand-primary,#4b76e5\)/);
  const count = css.match(/\.dsh-model-slider-count\{([^}]+)\}/)[1];
  assert.match(count, /color:var\(--dsw-alias-brand-primary,#4b76e5\)/);
  assert.match(count, /flex-direction:column/); assert.match(count, /writing-mode:horizontal-tb/); assert.match(count, /height:38px/);
  assert.match(css, /slider-numerator\{[^}]*border-bottom:1px solid currentColor/);
  assert.match(css, /label strong\{font-size:15px;color:var\(--dsw-alias-brand-primary,#4b76e5\);font-weight:700/);
  assert.match(css, /text-shadow:-1px -1px 0 var\(--preview-halo\)/);
  assert.match(css, /control\[data-dragging=true\],\.dsh-model-slider-control:focus-visible\{border-radius:12px;box-shadow:inset 0 0 0 2px/);
  effects.forEach(fn => fn?.()); assert.equal(styles.length, 0);
});

if (process.env.MODEL_SLIDER_TEST_TOKEN) test('test engine serves plugin and switches every catalog model without LLM calls', async () => {
  const base = 'http://127.0.0.1:3099';
  const auth = await fetch(base + '/?token=' + encodeURIComponent(process.env.MODEL_SLIDER_TEST_TOKEN), { redirect: 'manual' });
  const cookie = auth.headers.get('set-cookie')?.split(';')[0]; assert.ok(cookie);
  const get = path => fetch(new URL(path, base), { headers: { cookie }, signal: AbortSignal.timeout(20000) });
  assert.equal((await get('/dsh-model-slider/status.json')).status, 200); assert.equal((await get('/dsh-model-slider/__nope__')).status, 404);
  const html = await (await get('/')).text(), marker = 'globalThis["__DSH_BOOT__"] = ';
  const text = html.slice(html.indexOf(marker) + marker.length).split('</script>')[0].trim().replace(/;$/, '');
  const graph = JSON.parse(text), row = graph.entries.find(row => row.id === 'dsh-model-slider'); assert.ok(row);
  const bundle = await (await get(row.url)).text(); assert.match(bundle, /createPortal/); assert.match(bundle, /aria-orientation.*vertical/);
  async function rpc(method, args) {
    const r = await fetch(base + '/api/' + method, { method: 'POST', headers: { cookie, 'Content-Type': 'application/json' }, body: JSON.stringify({ type: 'client-request', rpcId: crypto.randomUUID(), method, payload: { args } }), signal: AbortSignal.timeout(20000) });
    const body = await r.json(); assert.equal(body.result.ok, true, JSON.stringify(body.result.error)); return body.result.value;
  }
  const plugin = load(), catalog = await rpc('session/modelCatalog', {}), view = plugin.modelView({ groups: catalog.groups, current: catalog.default });
  const { sessionId } = await rpc('session/create', { request: { cwd: '/data/user/0/com.deepseek.harness/files/dsh-local-fixes/model-slider', agentPreset: 'standard' } });
  let current = catalog.default;
  for (const target of view.rows) {
    const selection = plugin.selectionFor({ groups: catalog.groups, current }, target);
    const result = await rpc('session/selectModel', { request: { sessionId, ...selection } });
    assert.equal(result.selected.provider, target.provider); assert.equal(result.selected.model, target.model);
    const projection = await rpc('session/projections', { request: { sessionId } });
    assert.equal(projection.values.modelSelection.next.provider, target.provider); assert.equal(projection.values.modelSelection.next.model, target.model);
    current = selection;
  }
  console.log(`Verified ${view.rows.length} models across ${catalog.groups.length} providers through the native session API; no LLM calls.`);
});
