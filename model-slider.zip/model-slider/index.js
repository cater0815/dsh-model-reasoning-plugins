export const name = 'dsh-model-slider';
export const inject = ['webServer', 'connection'];
export function apply(ctx) {
  ctx.effect(() => ctx.webServer.register({
    kind: 'exact', path: '/dsh-model-slider/status.json',
    handler(req, res) {
      const denied = ctx.connection.requestRejection(req);
      res.writeHead(denied || 200, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
      res.end(JSON.stringify(denied ? { error: '请在已登录的 DSH 页面内访问' } : { plugin: name, version: '1.0.0', enabled: true }));
    },
  }), 'model-slider: status route');
}
